from __future__ import annotations
from collections import defaultdict
from datetime import datetime,timedelta,timezone
from email.utils import parsedate_to_datetime
import json
import math
import os
from pathlib import Path
import re
import threading
import time
import urllib.request as ur
import urllib.error as ue
import urllib.parse as up
from .model import utcnow, safe_url

class SourceError(Exception):
    pass

WORKABLE_HOST="apply.workable.com"
WORKABLE_INTERVAL_SECONDS=2.0
MAX_HOST_WAIT_SECONDS=120.0

def retry_after_seconds(headers,now=None):
    """Return an HTTP Retry-After delay (integer seconds or HTTP-date)."""
    value=str((headers.get("Retry-After") if headers else "") or "").strip()
    if not value:return None
    if value.isascii() and value.isdecimal():return int(value)
    try: stamp=parsedate_to_datetime(value)
    except (ValueError,TypeError,IndexError):return None
    if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
    now=now or datetime.now(timezone.utc)
    return max(0,math.ceil((stamp-now).total_seconds()))

class Client:
    def __init__(self,timeout=18,deadline=None,cooldowns_path=None,prior_trace_path=None):
        self.timeout=timeout; self.deadline=deadline or time.monotonic()+2700
        self.memory={}; self.lock=threading.RLock()
        self.host_locks=defaultdict(lambda:threading.BoundedSemaphore(2))
        # The 25 Workable boards share one API origin. Pace the host globally,
        # not each source independently, to prevent 429 bursts.
        self.host_locks[WORKABLE_HOST]=threading.BoundedSemaphore(1)
        self.host_next_at=defaultdict(float)
        self.cooldowns_path=Path(cooldowns_path) if cooldowns_path else None
        if self.cooldowns_path and self.cooldowns_path.exists():
            try:
                saved=json.loads(self.cooldowns_path.read_text(encoding="utf-8"))
                if saved.get("host")==WORKABLE_HOST:
                    until=datetime.fromisoformat(saved["retry_after_utc"])
                    if until.tzinfo is None:until=until.replace(tzinfo=timezone.utc)
                    remaining=max(0.0,(until-datetime.now(timezone.utc)).total_seconds())
                    self.host_next_at[WORKABLE_HOST]=time.monotonic()+remaining
            except (OSError,ValueError,KeyError,TypeError,OverflowError):
                # A corrupt optional pause file must not crash the entire radar.
                pass
        # First upgrade from 1.7.3: recover an unexpired server pause directly
        # from that version's existing last HTTP trace, before any new request.
        if prior_trace_path and self.host_next_at[WORKABLE_HOST]<=time.monotonic():
            try:
                prior=json.loads(Path(prior_trace_path).read_text(encoding="utf-8"))
                remaining=0.0
                for item in prior:
                    if item.get("status")!=429 or up.urlparse(
                        item.get("url","")).hostname!=WORKABLE_HOST:continue
                    match=re.search(r"pausa de (\d+) s",item.get("error",""))
                    if not match:continue
                    stamp=datetime.fromisoformat(item["checked_at"])
                    if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
                    deadline=stamp+timedelta(seconds=int(match.group(1))+5)
                    remaining=max(remaining,(deadline-datetime.now(timezone.utc)).total_seconds())
                if remaining>0:self.pause_workable(remaining)
            except (OSError,ValueError,KeyError,TypeError,OverflowError):
                pass
        self.requests=0; self.trace=[]
    def pause_workable(self,delay):
        """Remember a Workable 429 deadline, including across scheduled runs."""
        self.host_next_at[WORKABLE_HOST]=max(
            self.host_next_at[WORKABLE_HOST],time.monotonic()+delay)
        if self.cooldowns_path:
            until=datetime.now(timezone.utc)+timedelta(seconds=math.ceil(
                max(0,self.host_next_at[WORKABLE_HOST]-time.monotonic())))
            temp=self.cooldowns_path.with_suffix(".tmp")
            try:
                temp.write_text(json.dumps({"host":WORKABLE_HOST,
                    "retry_after_utc":until.isoformat(),"reason":"HTTP 429"},indent=2),
                    encoding="utf-8")
                os.replace(temp,self.cooldowns_path)
            except OSError:
                # Retain the in-process pause if the optional persistence fails.
                pass
    def wait_for_workable(self,host):
        if host!=WORKABLE_HOST:return
        while True:
            remaining=max(0.0,self.host_next_at[host]-time.monotonic())
            if remaining<=0:break
            if remaining>MAX_HOST_WAIT_SECONDS or time.monotonic()+remaining>self.deadline:
                raise SourceError(f"Workable limita las consultas; respetar pausa de {math.ceil(remaining)} s y reintentar en otra ejecución")
            time.sleep(min(remaining,5.0))
        self.host_next_at[host]=time.monotonic()+WORKABLE_INTERVAL_SECONDS
    def get(self,url,payload=None,form=False):
        if not safe_url(url): raise SourceError("URL HTTP(S) inválida")
        key=(url,json.dumps(payload,sort_keys=True),form)
        with self.lock:
            if key in self.memory: return self.memory[key]
        if time.monotonic()>self.deadline: raise SourceError("Se alcanzó el límite de tiempo de la ejecución")
        data=None
        headers={"User-Agent":"Mozilla/5.0 (compatible; AMLJobRadar/1.0; public read-only careers search)",
                 "Accept":"application/json,text/html,application/xml;q=0.9,*/*;q=0.8"}
        if payload is not None:
            data=(up.urlencode(payload) if form else json.dumps(payload)).encode()
            headers["Content-Type"]="application/x-www-form-urlencoded" if form else "application/json"
        result={"url":url,"final_url":url,"status":0,"checked_at":utcnow().isoformat(),"body":"","error":""}
        host=up.urlparse(url).netloc
        attempts=3 if host==WORKABLE_HOST else 2
        with self.host_locks[host]:
            for attempt in range(attempts):
                self.wait_for_workable(host)
                try:
                    with ur.urlopen(ur.Request(url,data=data,headers=headers),timeout=self.timeout) as resp:
                        raw=resp.read(40_000_001)
                        if len(raw)>40_000_000: raise SourceError("Respuesta demasiado grande; se declara la fuente incompleta")
                        result.update(status=resp.status,final_url=resp.url,
                            body=raw.decode(resp.headers.get_content_charset() or "utf-8",errors="replace"),error="")
                    break
                except ue.HTTPError as e:
                    result.update(status=e.code,final_url=e.url,error="HTTP "+str(e.code))
                    server_delay=retry_after_seconds(e.headers)
                    if e.code==429 and host==WORKABLE_HOST:
                        # Retry-After is a minimum, not a ceiling. Back off
                        # further if Workable keeps returning 429, and share
                        # that pause across all employers on the same host.
                        minimum=(10,30,90)[attempt]
                        delay=max(minimum,server_delay or 0)
                        self.pause_workable(delay)
                        if attempt<attempts-1 and delay<=MAX_HOST_WAIT_SECONDS:continue
                        result["error"]=f"HTTP 429: Workable limita consultas; pausa de {delay} s antes del siguiente intento"
                        break
                    if attempt<attempts-1 and e.code in (429,500,502,503,504,521,522,523,524):
                        delay=max(1,server_delay if server_delay is not None else 2)
                        if delay<=MAX_HOST_WAIT_SECONDS:
                            time.sleep(delay);continue
                        result["error"]=f"HTTP {e.code}: Retry-After {delay} s; no se reintenta antes de ese plazo"
                    break
                except (ue.URLError,TimeoutError,OSError) as e:
                    result["error"]=type(e).__name__+": "+str(e)[:180]
                    if attempt<attempts-1: continue
                finally:
                    with self.lock: self.requests+=1
            if host!=WORKABLE_HOST:time.sleep(0.12)
        with self.lock:
            self.memory[key]=result
            self.trace.append({k:v for k,v in result.items() if k!="body"})
        return result
    def json(self,url,payload=None):
        r=self.get(url,payload)
        if r["status"]!=200: raise SourceError(r["error"] or "HTTP "+str(r["status"]))
        try: return json.loads(r["body"])
        except ValueError as e: raise SourceError("El portal no devolvió JSON válido") from e
    def page(self,url):
        r=self.get(url)
        if r["status"]!=200: raise SourceError(r["error"] or "HTTP "+str(r["status"]))
        return r

"""Radar AML independiente. Python 3.10+, solo biblioteca estándar."""
__version__ = "1.7.5"

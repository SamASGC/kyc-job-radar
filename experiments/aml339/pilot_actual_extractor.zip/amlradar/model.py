from __future__ import annotations
import datetime as dt
import html
from html.parser import HTMLParser
import json
import re
import urllib.parse as up

UTC = dt.timezone.utc

def utcnow():
    return dt.datetime.now(UTC)

def clean(value):
    if value is None:
        return ""
    return re.sub(r"[ \t\r\f\v]+", " ", html.unescape(str(value))).strip()

class Page(HTMLParser):
    def __init__(self, body, base=""):
        super().__init__(convert_charrefs=True)
        self.base=base; self.links=[]; self.scripts=[]; self.attrs=[]
        self.text=[]; self.current_script=None; self.skip=0; self.anchor=None
        self.h1=[]; self.heading=None
        self.feed(body)
    def handle_starttag(self, tag, attrs):
        d=dict(attrs); self.attrs.append((tag,d))
        if tag in ("a","iframe","turbo-frame"):
            u=d.get("href") or d.get("src")
            if u:
                self.links.append({"url":up.urljoin(self.base,u),"text":"","tag":tag})
                if tag=="a": self.anchor=len(self.links)-1
        if tag=="script": self.current_script={"type":d.get("type",""),"text":""}
        if tag in ("style","noscript"): self.skip+=1
        if tag in ("p","li","div","br","h1","h2","h3","h4","section"): self.text.append("\n")
        if tag=="h1": self.heading=""
    def handle_endtag(self, tag):
        if tag=="script" and self.current_script is not None:
            self.scripts.append(self.current_script); self.current_script=None
        if tag=="a": self.anchor=None
        if tag in ("style","noscript"): self.skip=max(0,self.skip-1)
        if tag in ("p","li","div","h1","h2","h3","h4","section"): self.text.append("\n")
        if tag=="h1" and self.heading is not None:
            self.h1.append(clean(self.heading)); self.heading=None
    def handle_data(self, data):
        if self.current_script is not None: self.current_script["text"]+=data
        elif not self.skip:
            self.text.append(data)
            if self.anchor is not None: self.links[self.anchor]["text"]+=data
            if self.heading is not None: self.heading+=data
    def posts(self):
        out=[]
        def walk(d):
            if isinstance(d,list):
                for x in d: walk(x)
            elif isinstance(d,dict):
                t=d.get("@type",[])
                if t=="JobPosting" or isinstance(t,list) and "JobPosting" in t: out.append(d)
                for k,v in d.items():
                    if k not in ("@context","@type"): walk(v)
        for s in self.scripts:
            if "ld+json" in s["type"]:
                try: walk(json.loads(s["text"]))
                except (ValueError,TypeError): pass
        return out
    def visible(self):
        return "\n".join(clean(x) for x in "".join(self.text).splitlines() if clean(x))

def plain(value):
    s=html.unescape(str(value or ""))
    # Greenhouse can encode markup twice.
    if "&lt;" in s: s=html.unescape(s)
    if re.search(r"</?(?:p|li|div|h[1-6]|br|strong|ul|a)\b",s,re.I):
        try: return Page(s).visible()
        except Exception: return clean(re.sub("<[^>]+>"," ",s))
    return "\n".join(clean(x) for x in s.splitlines() if clean(x))

def location(value):
    if isinstance(value,str): return clean(value)
    if isinstance(value,list): return " / ".join(dict.fromkeys(filter(None,(location(x) for x in value))))
    if not isinstance(value,dict): return ""
    if value.get("fullLocation"): return clean(value["fullLocation"])
    if isinstance(value.get("address"),dict): return location(value["address"])
    if "name" in value and len(value)<4: return location(value["name"])
    keys=["addressLocality","addressRegion","addressCountry","city","region","country","name"]
    countries={"br":"Brazil","us":"United States","ca":"Canada","in":"India","au":"Australia","ph":"Philippines","sg":"Singapore",
        "gb":"United Kingdom","uk":"United Kingdom","lt":"Lithuania","es":"Spain","fr":"France","de":"Germany","nl":"Netherlands",
        "be":"Belgium","lu":"Luxembourg","pl":"Poland","pt":"Portugal","it":"Italy","ch":"Switzerland","se":"Sweden",
        "fi":"Finland","dk":"Denmark","no":"Norway","ee":"Estonia","lv":"Latvia","ie":"Ireland","mt":"Malta","cy":"Cyprus"}
    parts=[]
    for k in keys:
        if k not in value:continue
        v=location(value[k])
        if k in ("country","addressCountry"):v=countries.get(v.casefold(),v)
        if v:parts.append(v)
    return ", ".join(dict.fromkeys(parts)) or location(value.get("address",""))

def date_interval(value):
    """A posting date is an interval when no time/zone is supplied.

    Do not substitute a modification/creation/discovery date. For an unzoned
    date, UTC-12..UTC+14 bounds make freshness conservative.
    """
    if not value or not re.match(r"^20\d\d-\d\d-\d\d",str(value)): return None
    try:
        s=str(value).strip()
        if re.fullmatch(r"\d{4}-\d\d-\d\d",s):
            d=dt.datetime.fromisoformat(s).replace(tzinfo=UTC)
            return d-dt.timedelta(hours=14),d+dt.timedelta(hours=36),"day"
        d=dt.datetime.fromisoformat(s.replace("Z","+00:00"))
        if d.tzinfo is None:
            return d.replace(tzinfo=UTC)-dt.timedelta(hours=14),d.replace(tzinfo=UTC)+dt.timedelta(hours=12),"unzoned"
        d=d.astimezone(UTC)
        return d,d,"exact"
    except (ValueError,TypeError): return None

def freshness(value, now=None, hours=72):
    now=now or utcnow(); interval=date_interval(value)
    if interval is None: return "undated"
    lo,hi,_=interval; cutoff=now-dt.timedelta(hours=hours)
    if lo>now: return "future"
    if hi<cutoff: return "old"
    if lo<cutoff: return "boundary"
    return "fresh"

def expired(value, now=None):
    x=date_interval(value)
    return bool(x and x[1]<(now or utcnow()))

def from_ld(d, url):
    return {"id":str(d.get("identifier",{}).get("value","")) if isinstance(d.get("identifier"),dict) else "",
        "title":clean(d.get("title")),"description":plain(d.get("description")),
        "date":d.get("datePosted"),"date_field":"JSON-LD.datePosted",
        "date_semantics":"Publicación declarada por el empleador","url":d.get("url") or url,
        "apply_url":"","location":location(d.get("jobLocation")) or location(d.get("applicantLocationRequirements")),
        "valid_through":d.get("validThrough"),"hiring_organization":location(d.get("hiringOrganization")),
        "remote":d.get("jobLocationType")=="TELECOMMUTE","salary":location(d.get("baseSalary"))}

def safe_url(u):
    return isinstance(u,str) and up.urlparse(u).scheme in ("https","http") and bool(up.urlparse(u).hostname)

"""Listings from an employer's own career page that link out to an ATS.

This deliberately does NOT claim that an external vacancy is still accepting
applications or that its original publication date is known. It is a lead.
"""
from __future__ import annotations
from html.parser import HTMLParser
import re
from urllib.parse import urljoin, urlparse, urlunparse
from .model import clean, plain, safe_url
from .net import SourceError


class EmployerExternalLinks(HTMLParser):
    def __init__(self, body, base_url, allowed_hosts, external_path_pattern,
                 start_heading=r'^Open vacancies$', stop_heading=r'^Our teams$',
                 title_tag='h4', link_label_regex=r'^View role$'):
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.allowed_hosts = {x.lower() for x in allowed_hosts}
        self.external_path_pattern = re.compile(external_path_pattern, re.I)
        self.start_rx = re.compile(start_heading, re.I)
        self.stop_rx = re.compile(stop_heading, re.I)
        self.title_tag = title_tag
        self.link_label_rx = re.compile(link_label_regex, re.I)
        self.active = False
        self.current = None
        self.roles = []
        self.in_heading = None
        self.heading_parts = []
        self.in_anchor = False
        self.anchor_parts = []
        self.anchor_href = ''
        self.skip_depth = 0
        self.feed(body)
        self.finish()

    def finish(self):
        if self.current and self.current.get('href'):
            self.current['summary'] = plain(' '.join(self.current.pop('parts')))
            self.roles.append(self.current)
        self.current = None

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style', 'noscript'):
            self.skip_depth += 1
            return
        if self.skip_depth: return
        if tag in ('h1','h2','h3','h4','h5','h6'):
            self.in_heading = tag
            self.heading_parts = []
        if tag == 'a' and self.active:
            # Some employers render the vacancy title only inside the link
            # label, rather than as a stable h3/h4 heading. Capture the link
            # only while inside the configured open-roles section.
            self.in_anchor = True
            self.anchor_href = dict(attrs).get('href', '')
            self.anchor_parts = []

    def handle_endtag(self, tag):
        if tag in ('script', 'style', 'noscript'):
            self.skip_depth = max(0, self.skip_depth-1)
            return
        if self.skip_depth:return
        if tag == 'a' and self.in_anchor:
            label = ' '.join(clean(''.join(self.anchor_parts)).split())
            href = urljoin(self.base_url, self.anchor_href)
            u = urlparse(href)
            if (self.link_label_rx.fullmatch(label)
                    and safe_url(href)
                    and (u.hostname or '').lower() in self.allowed_hosts
                    and self.external_path_pattern.fullmatch(u.path)):
                if self.current is None:
                    # The fallback is intentionally narrower than the link
                    # regex: only an explicit 'Read More about <role>' label
                    # supplies a title; a generic 'Read More' is insufficient.
                    m = re.fullmatch(r'Read More about\s+(.+)', label, re.I)
                    if m and clean(m.group(1)):
                        self.current = {'title': clean(m.group(1)), 'parts': []}
                if self.current is not None:
                    self.current['href'] = urlunparse(u._replace(query='',fragment=''))
            self.in_anchor = False
        if tag == self.in_heading:
            title = clean(''.join(self.heading_parts))
            self.in_heading = None
            if not self.active and self.start_rx.fullmatch(title):
                self.active = True
            elif self.active and self.stop_rx.fullmatch(title):
                self.finish()
                self.active = False
            elif self.active and tag == self.title_tag and title:
                self.finish()
                self.current = {'title': title, 'parts': []}

    def handle_data(self, data):
        if self.skip_depth:return
        if self.in_heading is not None:
            self.heading_parts.append(data)
        elif self.in_anchor:
            self.anchor_parts.append(data)
        elif self.active and self.current:
            self.current['parts'].append(data)


def parse_employer_external(body, source):
    """Only count trusted role links *inside* the employer's open roles section."""
    allowed = source.get('external_allowed_hosts')
    if not isinstance(allowed, list) or not allowed:
        raise SourceError('Falta lista de dominios externos autorizados')
    parser = EmployerExternalLinks(
        body, source['careers_url'], allowed,
        source['external_job_path_regex'],
        source.get('external_start_heading_regex', '^Open vacancies$'),
        source.get('external_stop_heading_regex', '^Our teams$'),
        source.get('external_title_tag', 'h4'),
        source.get('external_link_label_regex', r'^View role$'))
    if not parser.roles:
        raise SourceError('El listado oficial no tiene enlaces de puesto reconocidos; no se presupone cero')
    distinct = {}
    for role in parser.roles:
        # Two copies in desktop/mobile markup point to the same external job.
        distinct.setdefault(role['href'], role)
    return list(distinct.values())

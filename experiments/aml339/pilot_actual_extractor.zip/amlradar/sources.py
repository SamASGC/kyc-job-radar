from __future__ import annotations
import html
from html.parser import HTMLParser
from email.utils import parsedate_to_datetime
import re
import time
import urllib.parse as up
import xml.etree.ElementTree as ET
from .model import Page, clean, plain, location, from_ld, expired, safe_url, utcnow
from .net import SourceError
from .employer_links import parse_employer_external

TITLE = re.compile(r"\b(?:AML|KYC|KYB|CDD|EDD|fin(?:ancial)?[\s-]*crim\w*|compliance|sanctions?|screening|risk|onboarding|investigat\w*|due diligence|fraud|financial intelligence|client review|reviews? analyst|blanqueo|conformit\w*|klientų pažinimo|pinigų plovimo|stebėsenos)\b",re.I)
NON_ROLE = re.compile(r"\b(?:engineer|developer|designer|recruiter|account executive|sales|product manager|product owner|architect|data scien\w*|software|IT auditor|IT risk|cyber|information security)\b",re.I)
POOL = re.compile(r"talent (?:pool|community)|open application|spontaneous|candidatura espont|general application",re.I)

class InlineEmailRoles(HTMLParser):
    """Extract inline job cards from a verified employer career page.

    Restrict to the open-roles section; headings outside it are never jobs.
    Text is descriptive evidence, never a guessed original posting date.
    """
    def __init__(self, body, start_regex, stop_regex, role_heading="h3"):
        super().__init__(convert_charrefs=True)
        self.start=re.compile(start_regex, re.I)
        self.stop=re.compile(stop_regex, re.I)
        self.role_heading=role_heading
        self.active=False;self.cards=[];self.current=None
        self.in_heading=None;self.heading_parts=[];self.skip=0
        self.feed(body)
        self.finish()
    def finish(self):
        if self.current:
            card=self.current
            card["description"]=plain("\n".join(card.pop("parts")))
            if card["description"]:self.cards.append(card)
            self.current=None
    def handle_starttag(self, tag, attrs):
        if tag in ("script","style","noscript"):
            self.skip+=1
        if self.skip:return
        if tag in ("h1","h2","h3","h4","h5","h6"):
            self.in_heading=tag;self.heading_parts=[]
        elif self.active and self.current and tag in ("p","li","div","section","ul","br"):
            self.current["parts"].append("\n")
    def handle_endtag(self, tag):
        if tag in ("script","style","noscript"):
            self.skip=max(0,self.skip-1);return
        if self.skip:return
        if tag==self.in_heading:
            title=clean("".join(self.heading_parts))
            self.in_heading=None
            if not self.active and self.start.search(title):
                self.active=True
            elif self.active and self.stop.search(title):
                self.finish();self.active=False
            elif self.active and tag==self.role_heading and title:
                self.finish();self.current={"title":title,"parts":[]}
            elif self.active and tag in ("h1","h2") and self.current:
                self.finish();self.active=False
        elif self.active and self.current and tag in ("p","li","div","section","ul"):
            self.current["parts"].append("\n")
    def handle_data(self, data):
        if self.skip:return
        if self.in_heading is not None:self.heading_parts.append(data)
        elif self.active and self.current:self.current["parts"].append(data)

def relevant(j):
    t=clean(j.get("title"))
    if NON_ROLE.search(t) or POOL.search(t): return False
    if TITLE.search(t): return True
    return bool(re.search(r"\b(?:analyst|investigator|officer|specialist|associate|operations)\b",t,re.I) and
        re.search(r"transaction monitoring|source of (?:funds|wealth)|adverse media|PEP screening|sanctions screening",j.get("description",""),re.I))

def ensure_list(data,key):
    if not isinstance(data,dict) or not isinstance(data.get(key),list):
        raise SourceError("Cambió el formato del listado ("+key+")")
    return data[key]

class Board:
    def __init__(self,source,client,max_minutes=15):
        self.source=source; self.client=client
        self.kind,self.host,self.token=source["route"]
        self.pages=0; self.total=None; self.warnings=[]; self.complete=True
        self.deadline=time.monotonic()+max_minutes*60
    def check_time(self):
        if time.monotonic()>self.deadline: raise SourceError("Fuente incompleta: se alcanzó el límite por portal")
    def js(self,url,payload=None):
        self.check_time(); self.pages+=1
        return self.client.json(url,payload)
    def page(self,url):
        self.check_time(); self.pages+=1
        return self.client.page(url)
    def job(self,title,url,**kwargs):
        j={"title":clean(title),"url":url,"apply_url":"","date":None,"description":"","location":"",
           "date_field":"","date_semantics":"Publicación declarada por el empleador"}
        j.update(kwargs); return j
    def rss_jobs(self,url):
        """Read an employer-hosted RSS feed without deriving dates from scan time."""
        r=self.page(url)
        try: root=ET.fromstring(r["body"])
        except ET.ParseError as e: raise SourceError("Feed RSS no es XML válido") from e
        if root.tag.lower()!="rss" or root.find("channel") is None:
            raise SourceError("El endpoint ya no publica un feed RSS")
        jobs=[]
        for x in root.findall("./channel/item"):
            title=clean(x.findtext("title")); url=clean(x.findtext("link"))
            u=up.urlparse(url)
            if u.hostname!=self.host or not safe_url(url):continue
            pub=clean(x.findtext("pubDate"));date=None
            if pub:
                try: date=parsedate_to_datetime(pub).isoformat()
                except (ValueError,TypeError,IndexError):pass
            jobs.append(self.job(title,url,description=plain(x.findtext("description")),
                date=date,date_field="RSS.pubDate" if date else "",
                date_semantics="Fecha de publicación explícita en RSS del empleador" if date else "Fecha no declarada",
                location=self.source.get("default_location","")))
        return jobs
    def listing(self):
        k,h,t=self.kind,self.host,self.token; jobs=[]
        if k=="ashby":
            d=self.js(f"https://{h}/posting-api/job-board/{up.quote(t)}")
            entries=ensure_list(d,"jobs")
            for x in entries:
                if x.get("isListed") is False: continue
                loc=location(x.get("location"))
                more=location([v.get("location") or v.get("address") for v in x.get("secondaryLocations",[])])
                jobs.append(self.job(x.get("title"),x.get("jobUrl"),id=x.get("id",""),
                    description=plain(x.get("descriptionHtml") or x.get("descriptionPlain")),
                    date=x.get("publishedAt"),date_field="Ashby.publishedAt",
                    date_semantics="Última publicación; puede corresponder a una republicación",
                    apply_url=x.get("applyUrl"),location=" / ".join(filter(None,[loc,more])),
                    remote=x.get("isRemote",False),salary=(x.get("compensation") or {}).get("compensationTierSummary","")))
        elif k=="greenhouse":
            entries=ensure_list(self.js(f"https://{h}/v1/boards/{t}/jobs?content=false"),"jobs")
            for x in entries:
                if x.get("internal_job_id") is None: continue
                region=".eu" if ".eu.greenhouse.io" in x.get("absolute_url","") else ""
                url=f"https://job-boards{region}.greenhouse.io/{t}/jobs/{x['id']}"
                jobs.append(self.job(x.get("title"),url,id=x["id"],date=x.get("first_published"),
                    date_field="Greenhouse.first_published",location=location(x.get("location")),
                    date_semantics="Primera publicación; updated_at no se utiliza",apply_url=url))
        elif k=="lever":
            offset=0
            while True:
                d=self.js(f"https://{h}/v0/postings/{t}?mode=json&skip={offset}&limit=100")
                if not isinstance(d,list): raise SourceError("Respuesta Lever inválida")
                for x in d:
                    desc=(x.get("description","")+"\n"+"\n".join(v.get("text","")+"\n"+v.get("content","") for v in x.get("lists",[]))+"\n"+x.get("additional",""))
                    jobs.append(self.job(x.get("text"),x.get("hostedUrl"),id=x.get("id"),description=plain(desc),
                        apply_url=x.get("applyUrl"),location=location(x.get("categories",{}).get("location")),
                        remote=x.get("workplaceType")=="remote"))
                if len(d)<100: break
                offset+=len(d)
                if offset>10000: raise SourceError("Paginación Lever no terminada")
        elif k=="workday":
            tenant=h.split(".")[0]; base=f"https://{h}/wday/cxs/{tenant}/{t}"
            terms=self.source.get("workday_search_terms") or [""]
            if not isinstance(terms,list) or not terms or any(not isinstance(q,str) for q in terms):
                raise SourceError("Búsquedas Workday mal configuradas")
            seen=set()
            for query in terms:
                offset=0; seen_in_query=set(); advertised=None
                while True:
                    d=self.js(base+"/jobs",{"limit":20,"offset":offset,"searchText":query})
                    entries=ensure_list(d,"jobPostings")
                    reported=d.get("total")
                    if advertised is None or isinstance(reported,int) and reported>0:advertised=reported
                    before=len(seen_in_query)
                    for x in entries:
                        path=x.get("externalPath")
                        if not path or path in seen_in_query:continue
                        seen_in_query.add(path)
                        if path in seen:continue
                        seen.add(path)
                        hint=re.search(r"Posted\s+(\d+)\+?\s+Days?\s+Ago",x.get("postedOn",""),re.I)
                        jobs.append(self.job(x.get("title"),f"https://{h}/{t}"+path,id=path,external_path=path,
                            location=location(x.get("locationsText")),posted_hint_old=bool(hint and int(hint[1])>=4)))
                    if not entries or advertised is not None and len(seen_in_query)>=advertised:break
                    if len(seen_in_query)==before: raise SourceError("Workday repite páginas; listado incompleto")
                    offset+=len(entries)
                    if offset>20000:raise SourceError("Límite de páginas Workday")
                if advertised is not None and len(seen_in_query)!=advertised:
                    self.complete=False
                    self.warnings.append(f"Workday '{query}': {len(seen_in_query)} de {advertised} vacantes anunciadas")
            if len(terms)==1 and not terms[0]:self.total=advertised
            else:self.warnings.append("Consulta temática Workday: solo títulos coincidentes con " + ", ".join(terms) + "; no es un barrido de todas las vacantes")
        elif k=="workable":
            payload={"query":"","location":[],"department":[],"worktype":[],"remote":[]}
            cursors=set()
            while True:
                d=self.js(f"https://{h}/api/v3/accounts/{t}/jobs",payload)
                entries=ensure_list(d,"results")
                self.total=d.get("total",self.total)
                for x in entries:
                    code=x["shortcode"]; url=x.get("url") or f"https://apply.workable.com/{t}/j/{code}/"
                    jobs.append(self.job(x.get("title"),url,id=code,date=x.get("published"),
                        date_field="Workable.published",apply_url=url.rstrip("/")+"/apply/",
                        location=location(x.get("location")),remote=x.get("remote",False)))
                cursor=d.get("nextPage")
                if not cursor: break
                if cursor in cursors: raise SourceError("Workable repite el cursor")
                cursors.add(cursor); payload=dict(payload,token=cursor)
            if self.total is not None and len(jobs)!=self.total:
                self.complete=False; self.warnings.append(f"Workable declaró {self.total}, se recuperaron {len(jobs)}.")
        elif k=="smartrecruiters":
            offset=0
            while True:
                d=self.js(f"https://{h}/v1/companies/{t}/postings?limit=100&offset={offset}")
                entries=ensure_list(d,"content"); self.total=d.get("totalFound",self.total)
                for x in entries:
                    jobs.append(self.job(x.get("name"),f"https://jobs.smartrecruiters.com/{t}/{x['id']}",
                        id=x["id"],date=x.get("releasedDate"),date_field="SmartRecruiters.releasedDate",
                        location=location(x.get("location"))))
                offset+=len(entries)
                if not entries or self.total is not None and offset>=self.total: break
                if offset>20000: raise SourceError("Límite de páginas SmartRecruiters")
        elif k=="recruitee":
            for x in ensure_list(self.js(f"https://{h}/api/offers/"),"offers"):
                jobs.append(self.job(x.get("title"),x.get("careers_url") or x.get("url"),id=x.get("id"),
                    description=plain(x.get("description","")+"\n"+(x.get("requirements") or "")),
                    apply_url=x.get("careers_apply_url") or "",location=location(x.get("location"))))
        elif k=="breezy":
            d=self.js(f"https://{h}/json")
            if not isinstance(d,list): raise SourceError("Listado Breezy inválido")
            for x in d:
                jobs.append(self.job(x.get("name"),x.get("url"),id=x.get("id"),
                    description=plain(x.get("description")),date=x.get("published_date"),date_field="Breezy.published_date",
                    apply_url=x.get("apply_url") or "",location=location(x.get("location"))))
        elif k=="personio":
            try:
                r=self.page(f"https://{h}/xml?language=en")
            except SourceError as e:
                # The XML feed is optional in Personio. A 404 there does not
                # imply that the official jobs board has no published roles.
                if "HTTP 404" not in str(e): raise
                r=self.page(self.source.get("careers_url") or f"https://{h}/")
                p=Page(r["body"],r["final_url"]); seen=set()
                for link in p.links:
                    url=up.urlparse(link["url"])
                    m=re.fullmatch(r"/job/(\d+)/?",url.path)
                    if url.hostname!=h or not m or m[1] in seen:continue
                    seen.add(m[1])
                    jobs.append(self.job(link["text"],f"https://{h}/job/{m[1]}?language=en",id=m[1]))
                if not jobs and not re.search(r"no (?:open |available )?(?:positions|vacancies|jobs)|keine offenen stellen",p.visible(),re.I):
                    raise SourceError("Personio: XML deshabilitado y sin enlaces de vacantes en HTML")
                self.warnings.append("Personio: feed XML 404; usado listado público HTML sin fechas declaradas")
            else:
                try: root=ET.fromstring(r["body"])
                except ET.ParseError as e: raise SourceError("XML de Personio inválido") from e
                for x in root.findall(".//position"):
                    code=x.findtext("id"); desc="\n".join(" ".join(v.itertext()) for v in x.findall(".//jobDescription"))
                    jobs.append(self.job(x.findtext("name"),f"https://{h}/job/{code}?language=en",
                        id=code,description=plain(desc),location=x.findtext("office","")))
        elif k=="bamboohr":
            for x in ensure_list(self.js(f"https://{h}/careers/list"),"result"):
                jobs.append(self.job(x.get("jobOpeningName"),f"https://{h}/careers/{x['id']}",id=x["id"],
                    location=location(x.get("location"))))
        elif k=="rss":
            jobs.extend(self.rss_jobs(f"https://{h}{t}"))
        elif k=="teamdash":
            # Bigbank publishes its jobs on its own careers page, linking to
            # individual Teamdash postings. The public index is server rendered.
            r=self.page(self.source["careers_url"]); p=Page(r["body"],r["final_url"])
            seen=set()
            for link in p.links:
                u=up.urlparse(link["url"])
                m=re.fullmatch(r"/p/job/([A-Za-z0-9]+)/([^/?#]+)",u.path)
                if not (u.hostname and u.hostname.endswith(".teamdash.com") and m):continue
                url=up.urlunparse(u._replace(query="",fragment=""))
                if url in seen:continue
                seen.add(url)
                jobs.append(self.job(m[2].replace("-"," ").title(),url,id=m[1]))
            if not jobs and not re.search(r"no (?:open |available )?(?:positions|vacancies|jobs)",p.visible(),re.I):
                raise SourceError("No se reconocieron enlaces Teamdash en el portal")
        elif k=="site_inline_email":
            # Small regulated institutions sometimes publish entire job cards
            # on a single official page and accept applications by email.
            # Never invent per-job detail URLs, publication dates or web forms.
            base=self.source["careers_url"]
            if up.urlparse(base).hostname!=h:
                raise SourceError("El dominio del listado no coincide con la fuente")
            r=self.page(base)
            if up.urlparse(r["final_url"]).hostname!=h:
                raise SourceError("El listado de empleos ha redirigido a otro dominio")
            cards=InlineEmailRoles(r["body"],
                self.source["inline_start_heading_regex"],
                self.source["inline_stop_heading_regex"],
                self.source.get("inline_role_heading","h3")).cards
            if not cards:
                raise SourceError("No se reconocieron las tarjetas de puestos; no se presupone cero vacantes")
            for card in cards:
                title=card["title"]
                ident=re.sub(r"[^a-z0-9]+","-",title.casefold()).strip("-")
                role_location=self.source.get("default_location", "")
                if self.source.get("inline_location_regex"):
                    found=re.search(self.source["inline_location_regex"],card["description"],re.I)
                    role_location=found.group(0) if found else ""
                jobs.append(self.job(title,base,id=ident,
                    description=card["description"],
                    location=role_location,
                    date_semantics="Fecha de publicación no declarada por el empleador"))
        elif k=="employer_external_jobs":
            # The official employer site is the source of currently advertised
            # titles. Links point to a third party and are NEVER treated as
            # verified live applications, dates, or detailed duty descriptions.
            base=self.source["careers_url"]
            r=self.page(base)
            parsed_host=up.urlparse(r["final_url"]).hostname
            if parsed_host not in (h,"www."+h):
                raise SourceError("La página de empleos cambió de dominio")
            for role in parse_employer_external(r["body"],self.source):
                match=re.search(
                    r"\b[A-Z][\wÀ-ſ-]+(?:\s+[A-Z][\wÀ-ſ-]+){0,2},\s*"
                    r"(?:Lithuania|Estonia|Latvia|United Kingdom|UK|Spain|Malta|Luxembourg|Germany|Switzerland)\b",
                    role["summary"])
                # Never infer every later job is in Lithuania just because the
                # employer is incorporated there.
                loc=match[0] if match else ""
                if self.source.get("external_role_location_regex"):
                    extra=re.search(self.source["external_role_location_regex"],role["summary"],re.I)
                    if extra: loc=extra.group(0)
                jobs.append(self.job(role["title"],role["href"],
                    id=role["href"], location=loc,
                    listing_only_external=True,
                    listing_evidence_url=base,
                    description=role["summary"],
                    date_semantics="El listado oficial no declara la fecha original"))
        elif k=="site_jobs":
            # Follow only official job links and *explicitly allowed* listing
            # pagination, never arbitrary search-engine/company links.
            # A website that starts returning empty HTML or redirecting to an
            # unrelated host must never be reported as successfully scanned.
            pattern=re.compile(t,re.I)
            link_pattern=(re.compile(self.source["link_text_pattern"],re.I)
                if self.source.get("link_text_pattern") else None)
            paging_pattern=(re.compile(self.source["listing_pagination_regex"],re.I)
                if self.source.get("listing_pagination_regex") else None)
            max_pages=int(self.source.get("max_listing_pages",1))
            if not (1<=max_pages<=30):
                raise SourceError("Límite de paginación del portal inválido")
            base_url=self.source["careers_url"]
            listing_host=up.urlparse(base_url).hostname
            allowed_listing_hosts={h,"www."+h,listing_host}
            queue=[base_url];visited=set();seen=set();last_page=None
            while queue and len(visited)<max_pages:
                current=queue.pop(0)
                if current in visited:continue
                if up.urlparse(current).hostname not in allowed_listing_hosts:
                    raise SourceError("La paginación se ha desplazado fuera de la fuente autorizada")
                try:
                    r=self.page(current)
                except SourceError as exc:
                    if not visited:raise
                    self.complete=False
                    self.warnings.append("Página adicional inaccesible: "+str(exc))
                    break
                canonical=up.urlparse(r["final_url"])
                if canonical.hostname not in allowed_listing_hosts:
                    raise SourceError("El portal ha redirigido a un dominio no atribuido")
                visited.add(current)
                p=Page(r["body"],r["final_url"]);last_page=p
                for link in p.links:
                    u=up.urlparse(link["url"])
                    if u.hostname not in (h,"www."+h):continue
                    if paging_pattern and paging_pattern.fullmatch(u.path) and safe_url(link["url"]) and u.hostname==listing_host:
                        # Only link-authorized pagination; forbid injected facet
                        # queries or third-party hosts that would grow the scan.
                        page_param=self.source.get("listing_page_query_param")
                        if page_param:
                            params=up.parse_qs(u.query)
                            if (page_param not in params or not params[page_param][0].isdigit()
                                    or int(params[page_param][0])<2):continue
                            more=up.urlunparse(u._replace(query=up.urlencode({
                                "LCID":up.parse_qs(up.urlparse(base_url).query).get("LCID",["2057"])[0],
                                page_param:params[page_param][0]}),fragment=""))
                        else:
                            more=up.urlunparse(u._replace(query="",fragment=""))
                        if more not in visited and more not in queue:queue.append(more)
                    if not pattern.fullmatch(u.path):continue
                    if link_pattern and not link_pattern.fullmatch(clean(link["text"])):continue
                    allowed=self.source.get("keep_query_params",[])
                    filtered=up.urlencode([(key,val) for key,val in up.parse_qsl(u.query)
                        if key in allowed]) if allowed else ""
                    url=up.urlunparse(u._replace(query=filtered,fragment=""))
                    if url in seen:continue
                    seen.add(url)
                    slug=u.path.rstrip("/").split("/")[-1]
                    title=(clean(link["text"]) if self.source.get("title_from_link")
                        else slug.replace("-"," ").title())
                    title_extract=self.source.get("title_extract_regex")
                    if title_extract:
                        m=re.search(title_extract,title,re.I)
                        if m:title=clean(m.group(1))
                    label=clean(link["text"])
                    region=re.search(r"\b(?:Lithuania|Latvia|Estonia|Spain|Malta|Luxembourg)(?:,\s*[A-Za-zÀ-ž]+)?\b",label,re.I)
                    jobs.append(self.job(title,url,id=slug+("?"+filtered if filtered else ""),
                        location=(region[0] if region else self.source.get("default_location",""))))
            if queue:
                self.complete=False
                self.warnings.append(f"Listado incompleto: límite de {max_pages} páginas alcanzado")
            if not jobs and not re.search(r"no (?:open |available )?(?:positions|vacancies|jobs)|no matching (?:jobs|roles)",
                    last_page.visible() if last_page else "",re.I):
                raise SourceError("No se reconocieron fichas de vacantes en el portal oficial")
            # A bank's homepage may link to more jobs than its capped RSS feed.
            # Where the employer advertises a separate catalogue total, compare
            # our official, server-rendered links to that total. Never infer
            # that the list is complete just because the homepage loaded.
            if self.source.get("catalog_count_url"):
                count_page=self.page(self.source["catalog_count_url"])
                count_text=Page(count_page["body"],count_page["final_url"]).visible()
                expression=self.source.get("catalog_count_regex",r"Nombre de résultats\s*:\s*(\d+)")
                m=re.search(expression,count_text,re.I)
                if m:
                    self.total=int(m.group(1))
                    if len(jobs)!=self.total:
                        self.complete=False
                        self.warnings.append(f"Catálogo oficial: {len(jobs)} enlaces de {self.total} vacantes anunciadas")
                else:
                    self.complete=False
                    self.warnings.append("No se pudo comprobar el total publicado por el catálogo oficial")
            # Keep explicit RSS publication dates for overlapping vacancies.
            # Do not use a 20-item RSS as proof that the bank has only 20 jobs.
            if self.source.get("supplemental_rss_url"):
                try:
                    feed=self.rss_jobs(self.source["supplemental_rss_url"])
                except SourceError as exc:
                    self.complete=False
                    self.warnings.append("RSS de fechas inaccesible: "+str(exc))
                else:
                    by_url={j["url"]:j for j in jobs}
                    # Some employers use SEO links in HTML but generic RSS
                    # detailoffre.aspx links differentiated only by idOffre.
                    # Dropping the RSS query would collapse distinct offers
                    # into one invalid generic URL. Join on employer IDs.
                    html_id_regex=self.source.get("rss_html_id_regex")
                    rss_id_param=self.source.get("rss_id_query_param")
                    by_id={}
                    if html_id_regex:
                        for j in jobs:
                            match=re.search(html_id_regex,up.urlparse(j["url"]).path,re.I)
                            if match:by_id[match.group(1)]=j
                    appended=set()
                    for entry in feed:
                        parsed=up.urlparse(entry["url"])
                        clean_url=up.urlunparse(parsed._replace(fragment=""))
                        rss_id=""
                        if rss_id_param:
                            params=up.parse_qs(parsed.query)
                            rss_id=(params.get(rss_id_param) or [""])[0]
                        target=by_id.get(rss_id) if rss_id else None
                        if target is None:target=by_url.get(clean_url)
                        if target is not None:
                            if entry["date"]:
                                target.update(date=entry["date"],date_field=entry["date_field"],
                                    date_semantics=entry["date_semantics"])
                        else:
                            # RSS and HTML are official but disagree about a
                            # job. Keep the FULL identifying query and report
                            # the inconsistency rather than invent coverage.
                            if clean_url in appended:continue
                            appended.add(clean_url)
                            entry["url"]=clean_url
                            jobs.append(entry)
                            self.complete=False
                            self.warnings.append("RSS contiene una vacante ausente del listado HTML")
        elif k=="vinted_html":
            # The official careers portal renders an initial server-side batch.
            # Its remaining positions require a separate, currently unverified
            # dynamic-pagination endpoint: report the coverage gap explicitly.
            r=self.page(self.source["careers_url"]); p=Page(r["body"],r["final_url"])
            seen=set()
            for link in p.links:
                u=up.urlparse(link["url"])
                m=re.fullmatch(r"/jobs/j/(\d+)",u.path)
                if u.hostname!="careers.vinted.com" or not m:continue
                url=up.urlunparse(u._replace(query="",fragment=""))
                if url in seen:continue
                seen.add(url)
                jobs.append(self.job(link["text"],url,id=m[1]))
            totals=re.search(r"Showing\s+(\d+)\s+out\s+of\s+(\d+)",p.visible(),re.I)
            if totals:
                self.total=int(totals[2])
                if len(jobs)<self.total:
                    self.complete=False
                    self.warnings.append(f"Vinted muestra {len(jobs)} de {self.total} puestos en HTML; el resto requiere paginación dinámica")
            else:
                if not jobs:
                    raise SourceError("Vinted: no se pudo interpretar el listado de vacantes")
                self.complete=False
                self.warnings.append("Vinted: no se reconoce el total anunciado; listado HTML sin cobertura verificable")
        elif k=="teamtailor":
            page=1; seen=set(); advertised=None
            while page<=100:
                u=f"https://{h}/jobs"+(f"?page={page}" if page>1 else "")
                r=self.page(u); p=Page(r["body"],r["final_url"])
                # Teamtailor localizes its count (e.g. Lithuanian Mano Bank)
                # and also uses the singular "1 job" on small boards.
                totals=re.findall(r"\b(\d+)\s+(?:jobs?\b|darbo pasiūlymai)",p.visible(),re.I)
                if totals: advertised=max(map(int,totals))
                before=len(seen)
                for l in p.links:
                    z=up.urlparse(l["url"])
                    if z.netloc==h and re.match(r"^/jobs/\d+",z.path):
                        url=up.urlunparse(z._replace(query="",fragment=""))
                        if url not in seen:
                            seen.add(url); jobs.append(self.job(l["text"],url))
                if advertised is not None and len(seen)>=advertised: break
                if len(seen)==before:
                    if page==1 and not re.search(r"no (?:open |matching )?(?:positions|jobs)|no jobs found",p.visible(),re.I):
                        raise SourceError("No se pudo interpretar el listado Teamtailor")
                    break
                if advertised is None and len(seen)-before<20: break
                page+=1
            self.total=advertised
            if advertised is not None and len(jobs)!=advertised:
                self.complete=False; self.warnings.append(f"Listado: {len(jobs)} enlaces de {advertised} anunciados.")
        elif k=="radancy":
            r=self.page(self.source["careers_url"]); p=Page(r["body"],r["final_url"])
            sections=[d for tag,d in p.attrs if d.get("data-ajax-url") and d.get("data-total-pages")]
            if not sections: raise SourceError("No se encontró la configuración pública de paginación")
            a=sections[0]; totalpages=int(a["data-total-pages"]); self.total=int(a.get("data-total-results","0"))
            seen=set()
            def append(page):
                for l in page.links:
                    if re.search(r"/(?:en/)?job/[^/]+/[^/]+/\d+/\d+",l["url"]):
                        if l["url"] not in seen:
                            seen.add(l["url"]);jobs.append(self.job(l["text"],l["url"]))
            params={"RecordsPerPage":a.get("data-records-per-page","15"),"SearchResultsModuleName":a.get("data-search-results-module-name","Search Results"),
                "SearchFiltersModuleName":"Search Filters","SearchType":a.get("data-search-type","5"),
                "SortCriteria":"0","SortDirection":"0","Keywords":"","Location":"","IsPagination":"true"}
            endpoint=up.urljoin(r["final_url"],a["data-ajax-url"])
            # The SSR first page can lag behind the public AJAX listing.
            # Use AJAX for page 1 too, keeping the pagination snapshot consistent.
            n=1
            while n<=totalpages:
                d=self.js(endpoint+"?"+up.urlencode(dict(params,CurrentPage=n)))
                chunk=d.get("results") or d.get("Results")
                if not isinstance(chunk,str): raise SourceError("Página Radancy sin HTML de resultados")
                page=Page(chunk,r["final_url"])
                if n==1:
                    meta=next((v for tag,v in page.attrs if v.get("data-total-results")),None)
                    if meta:
                        self.total=int(meta["data-total-results"])
                        totalpages=int(meta.get("data-total-pages",totalpages))
                append(page);n+=1
            if self.total and len(jobs)!=self.total:
                self.complete=False; self.warnings.append(f"Radancy declaró {self.total}; se leyeron {len(jobs)}.")
        else: raise SourceError("Adaptador no implementado: "+k)
        unique={}
        for j in jobs:
            if safe_url(j.get("url")):
                key=(j["url"],j.get("id")) if k=="site_inline_email" else j["url"]
                unique.setdefault(key,j)
        return list(unique.values())

    def hydrate(self,j):
        k,h,t=self.kind,self.host,self.token
        if k=="greenhouse":
            x=self.js(f"https://{h}/v1/boards/{t}/jobs/{j['id']}?questions=true")
            j.update(description=plain(x.get("content")),date=x.get("first_published"),
                form_definition=bool(x.get("questions")),hiring_organization=x.get("company_name",""))
        elif k=="workday":
            base=f"https://{h}/wday/cxs/{h.split('.')[0]}/{t}"
            x=self.js(base+j["external_path"]).get("jobPostingInfo")
            if not isinstance(x,dict): raise SourceError("Ficha Workday sin jobPostingInfo")
            url=x.get("externalUrl") or j["url"]
            j.update(title=clean(x.get("title")) or j["title"],description=plain(x.get("jobDescription")),
                date=x.get("startDate"),date_field="Workday.startDate",can_apply=x.get("canApply"),
                url=url,apply_url=url.rstrip("/")+"/apply",
                location=" / ".join(filter(None,[location(x.get("location")),location(x.get("additionalLocations"))])))
        elif k=="workable":
            x=self.js(f"https://{h}/api/v2/accounts/{t}/jobs/{j['id']}")
            j["description"]=plain("\n".join(str(x.get(z) or "") for z in ["description","requirements","benefits"]))
        elif k=="smartrecruiters":
            x=self.js(f"https://{h}/v1/companies/{t}/postings/{j['id']}")
            j["description"]=plain("\n".join(str(v.get("text") or "") for v in x.get("jobAd",{}).get("sections",{}).values() if isinstance(v,dict)))
            j["apply_url"]=x.get("applyUrl") or ""
            j["url"]=x.get("postingUrl") or j["url"]
            j["location"]=location(x.get("location")) or j["location"]
            j["can_apply"]=x.get("active")
        elif k=="bamboohr":
            x=self.js(f"https://{h}/careers/{j['id']}/detail").get("result",{}).get("jobOpening",{})
            j.update(description=plain(x.get("description")),date=x.get("datePosted"),date_field="BambooHR.datePosted",
                can_apply=x.get("jobOpeningStatus")=="Open",apply_url=j["url"])
        if not j.get("date") or not j.get("description") or k in ("teamtailor","radancy","recruitee","lever","personio"):
            self.read_post(j)
        return j

    def read_post(self,j):
        r=self.page(j["url"]); p=Page(r["body"],r["final_url"]); posts=p.posts()
        if self.kind=="teamdash":
            if p.h1:j["title"]=p.h1[0]
            j["description"]=p.visible()
        if self.kind in ("site_jobs","rss"):
            # Some employer detail templates put the DEPARTMENT in h1 (e.g.
            # Nayax "Legal & Compliance") instead of the vacancy title.
            # Preserve the employer's listing title for explicitly flagged boards.
            if p.h1 and not self.source.get("skip_h1_title"):
                j["title"]=p.h1[0]
            j["description"]=p.visible()
            # Some official templates (Nayax) show an explicit country +
            # contract type directly under the job heading. This is stronger
            # evidence than the location of the licensed group entity.
            if self.source.get("detail_location_line_regex"):
                country=re.search(self.source["detail_location_line_regex"],p.visible(),re.I|re.M)
                if country: j["location"]=clean(country.group(1))
            if self.source.get("rfc2822_date"):
                match=re.search(r"\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s+\d{1,2}\s+[A-Z][a-z]{2}\s+20\d\d\s+\d\d:\d\d:\d\d\s+(?:GMT|UTC)\b",p.visible())
                if match:
                    try:
                        j["date"]=parsedate_to_datetime(match[0]).isoformat()
                        j["date_field"]="Fecha original visible en la ficha oficial"
                        j["date_semantics"]="Fecha publicada por el empleador en formato RFC 2822"
                    except (ValueError,TypeError):pass
        if posts and self.kind!="site_inline_email":
            # An inline listing may contain JSON-LD for a *different* role.
            # Never transfer its date or title to another job on the page.
            target=next((x for x in posts if clean(x.get("title")).casefold()==clean(j["title"]).casefold()),posts[0] if len(posts)==1 else None)
            if target:
                x=from_ld(target,r["final_url"])
                had_date=bool(j.get("date"))
                for key in ("date","description","location","title","valid_through","hiring_organization","remote","salary"):
                    if x.get(key) and (key in ("title","location","valid_through","hiring_organization") or not j.get(key)):
                        j[key]=x[key]
                if not had_date and x.get("date"):
                    j["date_field"]=x["date_field"];j["date_semantics"]=x["date_semantics"]
        if re.search(r"\bCareers\b",j.get("title","")) and p.h1: j["title"]=p.h1[0]
        j["_page"]=r; j["_parser"]=p
        return j

    def verify(self,j):
        if self.kind=="site_inline_email":
            # Email applications are explicitly declared on the official page;
            # no HTTP form exists to submit and no email is sent.
            if "_page" not in j:self.read_post(j)
            page=j["_page"]
            if up.urlparse(page["final_url"]).hostname!=self.host:
                raise SourceError("Empleador redirigió a un dominio distinto")
            official_email=clean(self.source.get("inline_application_email"))
            if not re.fullmatch(r"[a-zA-Z0-9_.+\-]+@[a-zA-Z0-9.\-]+",official_email):
                raise SourceError("Email de candidatura no configurado correctamente")
            cards=InlineEmailRoles(page["body"],
                self.source["inline_start_heading_regex"],
                self.source["inline_stop_heading_regex"],
                self.source.get("inline_role_heading","h3")).cards
            if not any(x["title"].casefold()==j["title"].casefold() for x in cards):
                raise SourceError("El puesto ya no aparece en el listado oficial")
            if official_email.casefold() not in page["body"].casefold() or not re.search(
                    r"(?:apply by email|applications are sent by email)",page["body"],re.I):
                raise SourceError("No se ha comprobado la vía oficial de candidatura por email")
            if len(plain(j.get("description")))<120:
                raise SourceError("Descripción insuficiente para evaluar el encaje")
            j["apply_url"]=j["url"]
            j["active_checked_at"]=utcnow().isoformat()
            j["application_evidence"]=("Portal oficial anuncia candidatura por correo a "+official_email+
                "; no se ha probado la recepción de solicitudes")
            return j
        if j.get("can_apply") is False or expired(j.get("valid_through")):
            raise SourceError("La oferta declara cierre o canApply=false")
        if "_page" not in j: self.read_post(j)
        r=j["_page"]; p=j["_parser"]; visible=p.visible()
        if re.search(r"this (?:job|position) (?:is no longer|has expired)|job (?:not found|no longer available)|no longer accepting applications",visible,re.I):
            raise SourceError("El portal indica que la oferta está cerrada")
        app=j.get("apply_url") or ""
        if not app:
            candidates=[l for l in p.links if re.search(r"/(?:apply|applications?|candidates/new)(?:/|#|\?|$)|#(?:application|apply)$|vacancyId=",l["url"],re.I) or re.match(r"^\s*(?:apply|aplicar|postuler|bewerben|kandidatuok)\b",l["text"],re.I)]
            candidates=[l for l in candidates if not re.search(r"privacy|cookie|policy|application-process|how-to-apply|step-1-apply|interview|job-search|faq",l["url"],re.I)]
            candidates.sort(key=lambda l:not bool(re.search(r"vacancyId=|/applications/new|#application",l["url"],re.I)))
            if candidates: app=candidates[0]["url"]
            elif j.get("form_definition") or any(tag=="input" and d.get("type")=="file" for tag,d in p.attrs): app=j["url"]
            elif "candidate-pool-directive" in r["body"] and re.search("Apply Now",r["body"],re.I): app=j["url"]
        if not safe_url(app): raise SourceError("No se encontró acceso directo a candidatura")
        ar=r if app.split("#")[0]==j["url"].split("#")[0] else self.page(app)
        ap=Page(ar["body"],ar["final_url"])
        if re.search(r"this job is no longer available|position has been filled|job not found",ap.visible(),re.I):
            raise SourceError("El formulario de candidatura declara cierre")
        j["apply_url"]=app; j["active_checked_at"]=utcnow().isoformat()
        j["application_evidence"]="Formulario HTML accesible" if any(tag=="input" and d.get("type") in ("email","file") for tag,d in ap.attrs) else "Acceso HTTP 200; formulario del ATS con JavaScript"
        onboarding=re.search(r"\b(\d+)[ -]week[s]?\s+onboarding\s+program",p.visible(),re.I)
        if onboarding:
            j["training"]="El formulario menciona onboarding de "+onboarding[1]+" semanas; confirmar formación técnica, SOP y supervisión"
        if len(plain(j.get("description")))<120: raise SourceError("Descripción insuficiente para evaluar el encaje")
        return j

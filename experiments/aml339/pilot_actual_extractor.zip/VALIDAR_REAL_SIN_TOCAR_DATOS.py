#!/usr/bin/env python3
"""Prueba REAL y de SOLO LECTURA del laboratorio Radar AML.

No llama a runner.run ni a State, no toca datos/, fuentes.json,
programación, panel, avisos, candidaturas ni historial.
Separa éxito HTTP de prueba de extracción y de fecha de publicación.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import time
from amlradar.net import Client, SourceError
from amlradar.sources import Board, relevant
from amlradar.model import freshness, safe_url

BASE = Path(__file__).resolve().parent
DEFAULT_IDS = [
    'verifone',  # API ATS de referencia para distinguir red global de errores HTML
    'verifo-lithuania','demivolt-lithuania','lt-b4b-employmenthero',
    'lt-paystrax-official-external','lt-nikulipe-official',
    'lt-paynt-direct-employer','lt-finci-inline-careers',
    'lt-nayax-global-legal-compliance',
]
EXTERNAL_ONLY={'employer_external_jobs'}

def source_dict(root=BASE):
    data=json.loads((root/'fuentes.json').read_text(encoding='utf-8'))
    return {s['id']:s for s in data['sources']}

def error_class(exc):
    s=str(exc).lower()
    if '403' in s:return 'http_403'
    if '404' in s:return 'http_404'
    if '429' in s:return 'http_429'
    if re.search(r'name or service not known|nodename nor servname|name resolution|temporary failure in name resolution|dns|no such host|getaddrinfo|11001',s):
        return 'dns_error'
    if 'timed out' in s or 'timeout' in s:return 'timeout'
    if 'ssl' in s or 'certificate' in s:return 'tls_error'
    if 'no se reconocieron' in s or 'sin enlaces' in s:return 'parser_no_matches'
    return 'other_error'

def examine(source,client,max_samples=2, source_minutes=1):
    """Exercise real Board.listing / read_post / verify, without runner state."""
    board=Board(source,client,max_minutes=source_minutes)
    t0=time.monotonic()
    result={
        'source_id':source['id'],'employer':source['name'],
        'url':source['careers_url'],'adapter':source['route'][0],
        'state':'not_tested','count':None,'relevant_count':None,
        'dated_count':None,'samples':[],'warnings':[], 'complete':None,
    }
    trace_start=len(client.trace)
    try:
        jobs=board.listing()
        result.update(state='listing_extracted', count=len(jobs),
            relevant_count=sum(relevant(j) for j in jobs),
            dated_count=sum(bool(j.get('date')) for j in jobs),
            complete=board.complete)
        if not board.complete:result['state']='partial_listing'
        if not jobs:
            result['state']='empty_reported_by_adapter'
        # Favor relevant roles; additionally sample other roles to reveal parser issues.
        sample_order=sorted(jobs,key=lambda j:(not relevant(j),str(j.get('title'))))
        for job in sample_order[:max_samples]:
            item={
                'title':job.get('title',''), 'url':job.get('url',''),
                'location_initial':job.get('location') or '',
                'detail':'not_checked', 'apply_evidence':'none',
                'posting_date':None, 'freshness':'undated',
                'description_chars':0,
            }
            if not safe_url(job.get('url')):
                item['detail']='invalid_url';result['samples'].append(item);continue
            if source['route'][0] in EXTERNAL_ONLY or job.get('listing_only_external'):
                item.update(detail='external_link_unverified',
                    application='not_verified',freshness='undated')
                result['samples'].append(item);continue
            try:
                board.hydrate(job)
                if '_page' not in job: board.read_post(job)
                item.update(title=job.get('title',''),
                    location=job.get('location') or '',
                    posting_date=job.get('date'),
                    freshness=freshness(job.get('date'),hours=72),
                    description_chars=len(job.get('description') or ''),
                    detail='fetched')
                if relevant(job):
                    try:
                        board.verify(job)
                        item['detail']='verification_passed'
                        item['apply_evidence']=job.get('application_evidence') or 'verification_passed_without_form_details'
                        item['apply_url']=job.get('apply_url')
                    except Exception as e:
                        item['detail']='unverified_application'
                        item['detail_error']=str(e)[:220]
                else:
                    item['detail']='detail_read_only_non_aml'
            except Exception as e:
                item['detail']='fetch_or_parse_failed';item['detail_error']=str(e)[:220]
                item['error_class']=error_class(e)
            result['samples'].append(item)
        result['warnings']=board.warnings[:15]
    except Exception as e:
        result.update(state='listing_failed',error=str(e)[:350],error_class=error_class(e),
            complete=False)
    # Trace contains HTTP status, final_url and errors, but not response HTML.
    result['http_trace']=[{k:v for k,v in hit.items() if k in
        ('url','final_url','status','error','checked_at')} for hit in client.trace[trace_start:]][:60]
    result['http_statuses']=dict(Counter(str(hit.get('status',0)) for hit in result['http_trace']))
    result['elapsed_seconds']=round(time.monotonic()-t0,2)
    return result

def summarize(records):
    return {
        'sources_probed':len(records),
        'listing_extracted':sum(r['state'] in ('listing_extracted','partial_listing','empty_reported_by_adapter') for r in records),
        'failed':sum(r['state']=='listing_failed' for r in records),
        'jobs_found_in_listings':sum(r['count'] or 0 for r in records),
        'relevant_titles_in_listings':sum(r['relevant_count'] or 0 for r in records),
        'details_fetched':sum(j.get('detail') in ('verification_passed','unverified_application','detail_read_only_non_aml') for r in records for j in r['samples']),
        'applications_with_verification_passed':sum(j.get('detail')=='verification_passed' for r in records for j in r['samples']),
        'confirmed_recent_jobs':sum(j.get('freshness')=='fresh' and j.get('detail')=='verification_passed' for r in records for j in r['samples']),
        'dns_errors':sum(r.get('error_class')=='dns_error' for r in records),
    }

def markdown(report):
    s=report['summary']
    lines=['# Prueba HTTP real del laboratorio Radar AML',
        '',f"Hora UTC: {report['checked_at_utc']}",
        '', '**IMPORTANTE:** prueba de diagnóstico, NO publicación de una versión estable. ',
        'Las vacantes fechadas y con candidatura comprobada se cuentan solo entre las muestras examinadas.',
        '', f"- Fuentes examinadas: {s['sources_probed']}",
        f"- Listados extraídos: {s['listing_extracted']}",
        f"- Errores de listado: {s['failed']} (DNS: {s['dns_errors']})",
        f"- Puestos reconocidos en listados: {s['jobs_found_in_listings']}",
        f"- Títulos AML/KYC candidatos: {s['relevant_titles_in_listings']}",
        f"- Fichas leídas: {s['details_fetched']}",
        f"- Muestras con candidatura verificada: {s['applications_with_verification_passed']}",
        f"- Muestras recientes verificadas (72 h): {s['confirmed_recent_jobs']}",
        '', '| Fuente | Estado | Puestos | AML candidatos | HTTP |',
        '|---|---|---:|---:|---|']
    for r in report['sources']:
        http=', '.join(f'{code}:{n}' for code,n in r['http_statuses'].items()) or 'sin respuesta'
        lines.append(f"| {r['employer'].replace('|','/')} | {r['state']} | {r['count'] if r['count'] is not None else '—'} | {r['relevant_count'] if r['relevant_count'] is not None else '—'} | {http} |")
        for j in r['samples']:
            lines.append(f"  - {j['title']} — {j['detail']}; fecha: {j['posting_date'] or 'desconocida'}; lugar: {j.get('location',j.get('location_initial','')) or 'desconocido'}")
        if r.get('error'):lines.append('  - Error: '+r['error'].replace('|','/'))
    lines+=['','**Nota:** se hacen peticiones de solo lectura. Un HTTP 200 o una página con JavaScript no prueba que la candidatura continúe abierta. Los portales externos no se validan automáticamente.','','']
    return '\n'.join(lines)

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ids', default=','.join(DEFAULT_IDS),help='IDs de fuentes, separados por comas')
    p.add_argument('--timeout',type=int,default=8,help='Segundos por petición HTTP (3–30)')
    p.add_argument('--samples',type=int,default=2,help='Máximo de fichas por fuente (0–3)')
    p.add_argument('--minutes',type=int,default=2,help='Máximo de minutos por fuente (1–5)')
    args=p.parse_args(argv)
    if not 3<=args.timeout<=30 or not 0<=args.samples<=3 or not 1<=args.minutes<=5:
        p.error('Timeout (3–30), muestras (0–3) o minutos por fuente (1–5) fuera de rango')
    by_id=source_dict(); requested=[s.strip() for s in args.ids.split(',') if s.strip()]
    if len(set(requested))!=len(requested):p.error('Hay IDs repetidos')
    if len(requested)>12:p.error('Máximo de 12 fuentes por ejecución de diagnóstico')
    for name in requested:
        if name not in by_id:p.error('ID desconocido: '+name)
    fp=hashlib.sha256((BASE/'fuentes.json').read_bytes()).hexdigest()
    # One client per employer so an error does not affect the next trace.
    records=[]
    print('SMOKE REAL · Solo lectura · '+str(len(requested))+' fuentes',flush=True)
    for key in requested:
        client=Client(timeout=args.timeout,deadline=time.monotonic()+args.minutes*60)
        rec=examine(by_id[key],client,max_samples=args.samples,source_minutes=args.minutes)
        records.append(rec)
        print(f"{key}: {rec['state']} | puestos {rec['count']} | AML {rec['relevant_count']} | {rec.get('error_class','')}",flush=True)
    report={'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'mode':'public_http_read_only_no_state',
        'warning':'No se usan fechas de rastreo como fecha original. No modifica datos/ ni envía alertas.',
        'source_config_sha256_before':fp,
        'source_config_sha256_after':hashlib.sha256((BASE/'fuentes.json').read_bytes()).hexdigest(),
        'source_config_unmodified':fp==hashlib.sha256((BASE/'fuentes.json').read_bytes()).hexdigest(),
        'summary':summarize(records),'sources':records}
    out=BASE/'DIAGNOSTICOS';out.mkdir(exist_ok=True)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    jp=out/f'SMOKE_REAL_{stamp}.json';mp=out/f'SMOKE_REAL_{stamp}.md'
    jp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    mp.write_text(markdown(report),encoding='utf-8')
    print('\nRESUMEN: '+json.dumps(report['summary'],ensure_ascii=False),flush=True)
    print('JSON: '+str(jp),flush=True)
    print('Informe: '+str(mp),flush=True)
    return 0 if report['summary']['listing_extracted']>0 else 1

if __name__=='__main__':raise SystemExit(main())
